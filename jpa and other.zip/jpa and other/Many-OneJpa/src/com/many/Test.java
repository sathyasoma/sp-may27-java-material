package com.many;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {

	public static void main(String[] args) {
		
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("many");
		
		EntityManager entity=factory.createEntityManager();
		
		entity.getTransaction().begin();
		
		
		Department d= new Department();
		d.setDname("development");
		
		//employee1
		
		Employee emp= new Employee();
		emp.setEmpname("divya");
		emp.setEmpsal(12000);
		emp.setDesg("tech writer");
		emp.setDepartment(d);
		
	//employee2
		
		Employee emp1= new Employee();
		emp1.setEmpname("ramu");
		emp1.setEmpsal(67000);
		emp1.setDesg("ass tech");
		emp1.setDepartment(d);
		
	//employee3
		
		Employee emp2= new Employee();
		emp2.setEmpname("pavani");
		emp2.setEmpsal(8100);
		emp2.setDesg("transltr");
		emp2.setDepartment(d);
		
		
		
		
	//		entity.persist(d);
		entity.persist(emp);
		entity.persist(emp1);
		entity.persist(emp2);
		
		
		entity.getTransaction().commit();
		
		
		
		
	}
}
