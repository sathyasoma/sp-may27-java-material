package com.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {

	public static void main(String[] args) {
		
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("One2One");
		
		EntityManager entity=factory.createEntityManager();
		
		entity.getTransaction().begin();
		
	Laptop l1= new Laptop();
		
		l1.setLid(101);
		l1.setLname("hp");
		
		
		Student st= new Student();
		st.setRoolnum(1);
		st.setName("soma");
		st.setMarks(34);
		st.setLaptop(l1);
		
	
		
		entity.persist(st);
		//entity.persist(l1);
		
		entity.getTransaction().commit();
		
		
		
		
		
		
		
	}
}
