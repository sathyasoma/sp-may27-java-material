package com.cust;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {
public static void main(String[] args) {
	
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("custo");
	EntityManager entity=factory.createEntityManager();
	
	entity.getTransaction().begin();
	
//	Customer cus= new Customer();
//	cus.setCusid(123);
//	cus.setCusName("naresh");
//	
//	Shop s= new Shop();
//	s.setShopadd("ragini");
//	s.setShopid(10009);
//	s.setShopname("nandini shopx");
//	  
//	cus.setShop(s);
//	
//	entity.persist(cus);
	  // retrive data
	
	Customer customer=entity.find(Customer.class, 123);
	System.out.println(customer.getCusName());
System.out.println(customer.getShop().getShopname());
//	
	//Customer cus=entity.find(Customer.class,100);
	//Shop sc=entity.find(Shop.class,421);
	//cus.setCusName("sreya");
	//sc.setShopname("komasi");
	
	//entity.merge(cus);
	//entity.remove(s);
	
	
	
	entity.getTransaction().commit();
	
}
}
