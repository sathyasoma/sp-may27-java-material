package com.one;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {
public static void main(String[] args) {
	
	
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("one");
	EntityManager entity=factory.createEntityManager();
	entity.getTransaction().begin();
	
	Department d= new Department();
	d.setDname("hr");
	
	Employee emp= new Employee();
	emp.setEmpname("divya");
	emp.setEmpsal(10000);
	emp.setDesg("assmaager");
	emp.setDepartment(d);
	
	
	//entity.persist(d); //department
	entity.persist(emp);
	
	entity.getTransaction().commit();
}
}
