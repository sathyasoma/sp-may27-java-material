package com.oto;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class CustomerBi {
    
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int cusid;
	private String cusname;
	private String cusadd;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="cus_id")
	private ShopBi shop;
	
	
	public int getCusid() {
		return cusid;
	}
	public void setCusid(int cusid) {
		this.cusid = cusid;
	}
	public String getCusname() {
		return cusname;
	}
	public void setCusname(String cusname) {
		this.cusname = cusname;
	}
	public String getCusadd() {
		return cusadd;
	}
	public void setCusadd(String cusadd) {
		this.cusadd = cusadd;
	}
	public ShopBi getShop() {
		return shop;
	}
	public void setShop(ShopBi shop) {
		this.shop = shop;
	}
	
	
	
	
	
	
}
