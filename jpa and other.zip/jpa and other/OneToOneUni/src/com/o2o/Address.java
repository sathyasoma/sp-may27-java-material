package com.o2o;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="addressOne")
public class Address {

	@Id
	private int huno;
	private String street;
	private String state;
	
	
	public int getHuno() {
		return huno;
	}
	public void setHuno(int huno) {
		this.huno = huno;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	public Address() {
		// TODO Auto-generated constructor stub
	}
	public Address(int huno, String street, String state) {
		super();
		this.huno = huno;
		this.street = street;
		this.state = state;
	}
	@Override
	public String toString() {
		return "Address [huno=" + huno + ", street=" + street + ", state=" + state + "]";
	}
	
	
	
	
}
