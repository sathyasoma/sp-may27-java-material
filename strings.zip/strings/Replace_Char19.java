package com.strings;
//Write a program to replace a specified character with another character

public class Replace_Char19 {

	public static void main(String[] args)
	{
		String str1 = "Java Exercise";		
		String str2 = str1.replace('e', 'Q');
 
		System.out.println("Given String : " + str1);
		System.out.println("After String Character Replace : " + str2);
	}
}
