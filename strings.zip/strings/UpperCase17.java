package com.strings;
//Write a program to convert all the characters in a string to Uppercase

public class UpperCase17 {
	public static void main(String[] args)
	{
		String str = "Welcome Java Computer Education";
		String lwr_str = str.toUpperCase();
		System.out.println("Given String : " + str);
		System.out.println("String in Uppercase : " + lwr_str);
	}
}
