package com.strings;
//Write a program to create a character array containing the contents of a string

public class Create_CharArray15 {

	public static void main(String[] args)
	{
		String str = "Java Exercises.";
		char[] a = str.toCharArray();
		System.out.println(a);
	}
}
