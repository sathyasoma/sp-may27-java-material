package com.ui;

import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

import com.model.Employee;
import com.service.EmployeeService;
import com.service.EmployeeServiceImpl;

public class Client {

	public static void main(String[] args) {
		EmployeeService service= new EmployeeServiceImpl();
		
		while(true) {
		System.out.println("****EMployee Management Application****");
		System.out.println("1.Add Employee");
		System.out.println("2.update Employee");
		System.out.println("3.get Employee");
		System.out.println("4.delete Employee");
		System.out.println("5.get all Employee");
		
		Scanner sc= new Scanner(System.in);
		int option=sc.nextInt();
		
		switch (option) {
		case 1:
			System.out.println("Insert Employee details");
			System.out.println("Enter EMployee NAME");
			String empname=sc.next();
			System.out.println("enter employee salary");
			int empsal=sc.nextInt();
			System.out.println("Enter Employee addeess");
			String empadd=sc.next();
			System.out.println("Enter EMployee mail id");
			String empmail=sc.next();
			
			
			Employee emp= new Employee(empname, empsal, empadd, empmail);
			int empid=service.addEmployee(emp);
			System.out.println("employee addedd sucfuly :"+empid);
			break;
		case 2:
			System.out.println("Employee Update ");
			System.out.println("Employee id");
			int eid1= sc.nextInt();
			System.out.println("Enter EMployee NAME");
			String ename=sc.next();
			System.out.println("enter employee salary");
			int esal=sc.nextInt();
			System.out.println("Enter Employee addeess");
			String eadd=sc.next();
			System.out.println("Enter EMployee mail id");
			String email=sc.next();
			
			Employee emp1= new Employee(ename, esal, eadd, email);
			Employee empoh=service.updateEmployee(eid1, emp1);
			System.out.println("Employee updaed :"+eid1);
			break;
		case 3:
			System.out.println("EMployee get details");
			System.out.println("enTER eMPLOYE ID");
			int eid2=sc.nextInt();
			
			Employee empoo=service.getEmployee(eid2);
			System.out.println(empoo);
			break;
		case 4:
			System.out.println("Employee deleytion");
			System.out.println("ENter MEployee id");
			int eid3= sc.nextInt();
			service.deleteEmployee(eid3);
			break;
		case 5:
			Set<Entry<Integer, Employee>> result=service.getAllEmployees();
			Iterator<Entry<Integer,Employee>> itr=result.iterator();
			while(itr.hasNext())
			{
				Entry<Integer, Employee> finalResult= itr.next();
				System.out.println(finalResult.getKey()+" "+finalResult.getValue());
			}
			break;

		default:
			System.out.println("invalid option eneterd");
			break;
		}
		}
	}
}
