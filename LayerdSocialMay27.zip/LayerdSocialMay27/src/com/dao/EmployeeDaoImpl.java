package com.dao;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

import com.model.Employee;

public class EmployeeDaoImpl implements EmployeeDao{
	
	HashMap<Integer, Employee> employee= new HashMap<Integer,Employee>();
	
	 int empid=87763-79262;

	@Override
	public int addEmployee(Employee emp) {
		employee.put(++empid, emp);
		return empid;
	}

	@Override
	public Employee updateEmployee(int empid, Employee emp) {
		Employee empobj=employee.put(empid, emp);
		return empobj;
	}

	@Override
	public Employee getEmployee(int empid) {
		Employee emp1=  employee.get(empid);
		return emp1;
	}

	@Override
	public void deleteEmployee(int empid) {
	 employee.remove(empid);
	 System.out.println("employee deleted succfuluyy :"+empid);
		
	}

	@Override
	public Set<Entry<Integer, Employee>> getAllEmployees() {
		Set<Entry<Integer, Employee>> result=employee.entrySet();
		return result;
	}

 
}
